<table>
    <thead>
        <tr>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Jenis Kelamin</th>
            <th>No Tlp</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Nama</td>
            <td>Surabaya</td>
            <td>Laki-Laki</td>
            <td>019248856</td>
        </tr>
    </tbody>
</table>