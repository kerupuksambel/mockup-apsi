<table>
    <thead>
        <tr>
            <th>
                Kegiatan
            </th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Kegiatan 1</td>
            <td><a href="peserta.php?id=1">Lihat</td>
        </tr>
        <tr><td>Kegiatan 2</td></tr>
        <tr><td>Kegiatan 3</td></tr>
        <tr><td>Kegiatan 4</td></tr>
    </tbody>
</table>