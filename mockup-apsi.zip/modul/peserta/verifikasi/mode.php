<a href="view.php?m=donasi">Donasi</a>
<a href="view.php?m=peserta">Peserta</a>