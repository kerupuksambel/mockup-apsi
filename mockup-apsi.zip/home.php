<ul>
    <li><a href="modul/peserta.php">Peserta</a></li>
    <li><a href="modul/kegiatan.php">Kegiatan</a></li>
    <li><a href="modul/nilai.php">Nilai</a></li>
    <li><a href="modul/keuangan.php">Keuangan</a></li>
    <li><a href="modul/akun.php">Akun</a></li>
</ul>
    