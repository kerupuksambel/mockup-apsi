<table>
    <thead>
        <tr>
            <th>
                Record
            </th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Record 1</td>
            <td><a href="detail_keuangan.php?id=1">Lihat</td>
        </tr>
        <tr>
            <td>Record 2</td>
            <td><a href="detail_keuangan.php?id=2">Lihat</td>
        </tr>
        <tr>
            <td>Record 3</td>
            <td><a href="detail_keuangan.php?id=3">Lihat</td>
        </tr>
        <tr>
            <td>Record 4</td>
            <td><a href="detail_keuangan.php?id=4">Lihat</td>
        </tr>
    </tbody>
</table>