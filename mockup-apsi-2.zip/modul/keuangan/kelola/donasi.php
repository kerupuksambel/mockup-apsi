<table>
    <thead>
        <tr>
            <th>
                Donasi
            </th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Donasi 1</td>
            <td><a href="detail_donasi.php?id=1">Lihat</td>
        </tr>
        <tr>
            <td>Donasi 2</td>
            <td><a href="detail_donasi.php?id=2">Lihat</td>
        </tr>
        <tr>
            <td>Donasi 3</td>
            <td><a href="detail_donasi.php?id=3">Lihat</td>
        </tr>
        <tr>
            <td>Donasi 4</td>
            <td><a href="detail_donasi.php?id=4">Lihat</td>
        </tr>
    </tbody>
</table>