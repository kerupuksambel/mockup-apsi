
<li><a href="peserta/daftar_peserta/kegiatan.php">Lihat Peserta Kegiatan</a></li>
<li><a href="peserta/verifikasi/mode.php">Verifikasi</a></li>