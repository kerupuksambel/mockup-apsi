<table>
    <thead>
        <tr>
            <th>
                Kegiatan
            </th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Kegiatan 1</td>
            <td><a href="detail.php?id=1">Lihat</td>
        </tr>
        <tr>
            <td>Kegiatan 2</td>
            <td><a href="detail.php?id=2">Lihat</td>
        </tr>
        <tr>
            <td>Kegiatan 3</td>
            <td><a href="detail.php?id=3">Lihat</td>
        </tr>
        <tr>
            <td>Kegiatan 4</td>
            <td><a href="detail.php?id=4">Lihat</td>
        </tr>
    </tbody>
</table>