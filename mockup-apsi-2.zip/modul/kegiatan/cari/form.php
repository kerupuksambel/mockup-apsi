<form action="result.php">
    <input type="text" placeholder="Cari disini..." name="query"/>
    <input type="submit" value="Cari">
</form>