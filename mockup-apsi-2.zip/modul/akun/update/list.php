<table>
    <thead>
        <tr>
            <th>
                Akun
            </th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Akun 1</td>
            <td><a href="detail.php?id=1">Lihat</td>
        </tr>
        <tr>
            <td>Akun 2</td>
            <td><a href="detail.php?id=2">Lihat</td>
        </tr>
        <tr>
            <td>Akun 3</td>
            <td><a href="detail.php?id=3">Lihat</td>
        </tr>
        <tr>
            <td>Akun 4</td>
            <td><a href="detail.php?id=4">Lihat</td>
        </tr>
    </tbody>
</table>